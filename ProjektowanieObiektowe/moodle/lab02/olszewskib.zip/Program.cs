﻿namespace ProjektowanieObiektowe;
class Program
{
    static void Main(string[] args)
    {
        

        var author0 = new Author("Francis", "Coppola", 1939, 32);
        var author1 = new Author("Steven", "Spielberg", 1956, 73);
        var author2 = new Author("Charlie", "Chaplin", 1889, 6);
        var author3 = new Author("Vince", "Gilligan", 1967, 17);
        var author4 = new Author("Rian", "Johnson", 1973, 29);
        var author5 = new Author("Greg", "Daniels", 1963, 5);
        var author6 = new Author("Troy", "Miller", 1960, 0);
        var author7 = new Author("Victor", "Nelli, Jr.", 1960, 0);
        var author8 = new Author("Charles", "McDougall", 1960, 0);

        var movie0 = new Movie("Apocalypse now", "war film", author0, 147, 1979);
        var movie1 = new Movie("The Godfather", "criminal", author0, 175, 1972 );
        var movie2 = new Movie("Raiders of the lost ark", "adventure", author1, 115, 1981);
        var movie3 = new Movie("The Great Dictator", "comedy", author2, 125, 1940);

        var episode0 = new Episode("Fly", 45, 2010, author4);
        var episode1 = new Episode("Ozymandias", 50, 2013, author4);
        var episode2 = new Episode("Pilot", 43, 2008, author3);
        var episode3 = new Episode("Dwight K. Schrute, (Acting) Manager", 22, 2011,author6);
        var episode4 = new Episode("The Carpet", 23, 2006, author7);
        var episode5 = new Episode("Dwight's Speech", 22, 2006, author8);

        Episode[] episodes0 = { episode0, episode1, episode2 };
        var series0 = new Series("Breaking Bad", "drama", author3,episodes0);
        
        Episode[] episodes1 = { episode3, episode4, episode5 };
        var series1 = new Series("The Office US", "horror", author5, episodes1);

        Console.WriteLine(author0);
        Console.WriteLine(author1);
        Console.WriteLine(author2);
        Console.WriteLine(author3);
        Console.WriteLine(author4);
        Console.WriteLine(author5);
        Console.WriteLine(author6);
        Console.WriteLine(author7);
        Console.WriteLine(author8);
        Console.WriteLine();
        Console.WriteLine(movie0);
        Console.WriteLine(movie1);
        Console.WriteLine(movie2);
        Console.WriteLine(movie3);
        Console.WriteLine();
        Console.WriteLine(series0);
        Console.WriteLine(series1);

        Console.WriteLine();
        Console.WriteLine("Test1");
        Console.WriteLine();
        
        
        
        
        
    } 
}
 