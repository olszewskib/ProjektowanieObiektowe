namespace ProjektowanieObiektowe;

public class MoviePairs
{
    public List<Tuple<string, object>> Movies = new List<Tuple<string, object>>();

    public MoviePairs(string title, string genre, AuthorPairs author, int releaseYear, int duration)
    {
        Movies.Add(new Tuple<string, Object>("Title", title));
        Movies.Add(new Tuple<string, Object>("Genre", genre));
        Movies.Add(new Tuple<string, Object>("Director", author));
        Movies.Add(new Tuple<string, Object>("ReleaseYear", releaseYear));
        Movies.Add(new Tuple<string, Object>("Duration", duration));
        
    }
}

public class AuthorPairs
{
    public List<Tuple<string, object>> Authors = new List<Tuple<string, object>>();
    
    public AuthorPairs(string name, string surname, int birthYear, int awards)
    {
        Authors.Add(new Tuple<string, Object>("Name", name));
        Authors.Add(new Tuple<string, Object>("Surname", surname));
        Authors.Add(new Tuple<string, Object>("BirthYear", birthYear));
        Authors.Add(new Tuple<string, Object>("Awards", awards));
    }
}

public class EpisodePairs
{
    public List<Tuple<string, object>> Episodes = new List<Tuple<string, object>>();
    
    public EpisodePairs(string title, int duration, int releaseYear, AuthorPairs author)
    {
        Episodes.Add(new Tuple<string, Object>("Title", title));
        Episodes.Add(new Tuple<string, Object>("Duration", duration));
        Episodes.Add(new Tuple<string, Object>("ReleaseYear", releaseYear));
        Episodes.Add(new Tuple<string, Object>("Director", author));
    }
}

public class SeriesPairs
{
    public List<Tuple<string, object>> Series = new List<Tuple<string, object>>();
    
    public SeriesPairs(string title, string genre, AuthorPairs showrunner, EpisodePairs[] episodes)
    {
        Series.Add(new Tuple<string, Object>("Title", title));
        Series.Add(new Tuple<string, Object>("Genre", genre));
        Series.Add(new Tuple<string, Object>("Showrunner", showrunner));
        Series.Add(new Tuple<string, Object>("Episodes", episodes));
    }
}
