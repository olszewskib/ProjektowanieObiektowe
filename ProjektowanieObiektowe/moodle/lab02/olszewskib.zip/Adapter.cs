namespace ProjektowanieObiektowe;

public class MovieAdapter : IMovie
{
    public MoviePairs Element;

    public string Title
    {
        get
        {
            string title="";
            foreach (var field in Element.Movies)
            {
                if (field.Item1 == "Title")
                    title = field.Item2 as string;
            }

            return title;
        }
        set{}
    }

    public string Genre
    {
        get
        {
            string genre="";
            foreach (var field in Element.Movies)
            {
                if (field.Item1 == "Genre")
                    genre = field.Item2 as string;
            }

            return genre;
        }
        set{}
    }

    public Author Director
    {
        get
        {
            Object director = null;
            foreach (var field in Element.Movies)
            {
                if (field.Item1 == "Director")
                    director = field.Item2 as Author;
            }

            return director as Author;
        }
        set{}
    }

    public int ReleseYear
    {
        get
        {
            int releaseYear = 0;
            foreach (var field in Element.Movies)
            {
                if (field.Item1 == "ReleaseYear")
                    releaseYear = (int)field.Item2;
            }

            return releaseYear;
        }
        set{}
    }

    public int Duration
    {
        get
        {
            int duration = 0;
            foreach (var field in Element.Movies)
            {
                if (field.Item1 == "Duration")
                    duration = (int)field.Item2;
            }

            return duration;
        }
        set{}
    }
}

public class EpisodesAdapter : IEpisode
{
    public EpisodePairs Element;

    public string Title
    {
        get
        {
            string title="";
            foreach (var field in Element.Episodes)
            {
                if (field.Item1 == "Title")
                    title = field.Item2 as string;
            }

            return title;
        }
        set{}
    }

    public int Duration
    {
        get
        {
            int duration = 0;
            foreach (var field in Element.Episodes)
            {
                if (field.Item1 == "Duration")
                    duration = (int)field.Item2;
            }

            return duration;
        }
        set{}
    }

    public int ReleaseYear
    {
        get
        {
            int releaseYear = 0;
            foreach (var field in Element.Episodes)
            {
                if (field.Item1 == "ReleaseYear")
                    releaseYear = (int)field.Item2;
            }

            return releaseYear;
        }
        set{}
    }

    public Author Director
    {
        get
        {
            Object director = null;
            foreach (var field in Element.Episodes)
            {
                if (field.Item1 == "Director")
                    director = field.Item2 as Author;
            }

            return director as Author;
        }
        set{}
    }

    public EpisodesAdapter(EpisodePairs element)
    {
        Element = element;
    }
}

public class SeriesAdapter : ISeries
{
    public SeriesPairs Element;

    public string Title
    {
        get
        {
            string title="";
            foreach (var field in Element.Series)
            {
                if (field.Item1 == "Title")
                    title = field.Item2 as string;
            }

            return title;
        }
        set{}
    }

    public string Genre
    {
        get
        {
            string genre="";
            foreach (var field in Element.Series)
            {
                if (field.Item1 == "Genre")
                    genre = field.Item2 as string;
            }

            return genre;
        }
        set{}
    }

    public Author Showrunner
    {
        get
        {
            Object showrunner = null;
            foreach (var field in Element.Series)
            {
                if (field.Item1 == "Showrunner")
                    showrunner = field.Item2 as Author;
            }

            return showrunner as Author;
        }
        set{}
    }

    public IEpisode[] Episodes
    {
        get
        {
            EpisodePairs[] episodes = null;
            foreach (var field in Element.Series)
            {
                if (field.Item1 == "Episodes")
                    episodes = field.Item2 as EpisodePairs[];
            }

            var result = new List<IEpisode>();

            foreach (var ep in episodes)
            {
                result.Add(new EpisodesAdapter(ep));
            }

            return result.ToArray();
        }
        set{}
    }
}